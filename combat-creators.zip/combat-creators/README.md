# Combat Creators — Hook Generator

## Deployment Instructions (5 minutes)

### Step 1 — Upload your logo
Replace the `public/logo.png` file with your actual logo image.
Rename your logo file to `logo.png` and drop it in the `public/` folder.

### Step 2 — Push to GitHub
1. Go to github.com and create a free account if you don't have one
2. Click "New repository"
3. Name it `combat-creators-hook-generator`
4. Upload all these files (drag and drop the whole folder)
5. Click "Commit changes"

### Step 3 — Deploy on Vercel
1. Go to vercel.com and sign up with your GitHub account
2. Click "Add New Project"
3. Select your `combat-creators-hook-generator` repo
4. Click "Deploy" — Vercel will build it automatically

### Step 4 — Add your API key (IMPORTANT)
1. In Vercel, go to your project Settings
2. Click "Environment Variables"
3. Add a new variable:
   - Name: `ANTHROPIC_API_KEY`
   - Value: your API key from console.anthropic.com
4. Click Save
5. Go to Deployments and click "Redeploy" to apply the key

### Step 5 — Share your link!
Vercel gives you a free URL like:
`https://combat-creators-hook-generator.vercel.app`

Share that link with your students and community. Done!

---

## File Structure
```
combat-creators/
├── api/
│   └── generate.js       (backend — keeps your API key secure)
├── public/
│   ├── index.html        (the app)
│   └── logo.png          (replace with your logo)
├── vercel.json           (deployment config)
└── README.md             (this file)
```

## Cost
Each hook generation costs roughly $0.002–0.005 (fractions of a cent).
Even with 1,000 generations per month = ~$2–5/month total.

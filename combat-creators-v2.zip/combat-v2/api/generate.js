export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Invalid request body' });
  }

  const SYSTEM_PROMPT = `You are an On-Screen Text Hook Generator for short-form video content (Instagram Reels, TikToks, YouTube Shorts).

Your ONLY job is to generate the best possible on-screen text hooks — the visual text that appears on screen at the START of a video. You do NOT write verbal scripts, captions, or post copy.

FUNCTIONAL WORDS BLACKLIST (keep to 33% or less of total words):
a, this, he, she, they, in, on, at, some, is, are, not, up

RULES FOR EVERY HOOK:
- Length: 5 to 12 words. Must fit on 1 or 2 lines on screen.
- Never repeat the same content word twice
- Must create genuine curiosity that makes viewers want to keep watching
- Must contain at least one power word tied to a persuasive mechanism:
  Logos: proven, exactly, formula, step-by-step, stats, data
  Pathos: secret, mistake, warning, finally, broke, dream, real
  Ethos: how I, after X years, what they won't tell you
- Use capitalization: all lowercase, Title Case, or ONE word in ALL CAPS for emphasis
- Use pattern interrupts when natural: parentheses or quotation marks

WHEN TO ASK VS GENERATE:
- Full script pasted: generate hooks immediately, no questions
- Vague topic with little detail: ask 1-3 clarifying questions
- Topic with reasonable context: generate hooks immediately

You must respond with ONLY a raw JSON object. No markdown, no code fences, no explanation before or after. Just the JSON.

Use this format for clarifying questions:
{"type":"clarify","message":"Quick questions before I generate your hooks:","questions":["question one","question two"]}

Use this format for hooks:
{"type":"hooks","hooks":[{"text":"hook text here","why":"one sentence explanation","formatting":"exact formatting instructions"}]}

Generate 3 to 5 hooks. Each must be a different angle: curiosity, emotion, outcome, credibility, or challenge.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1500,
        system: SYSTEM_PROMPT,
        messages: messages
      })
    });

    if (!response.ok) {
      const error = await response.text();
      return res.status(response.status).json({ error });
    }

    const data = await response.json();
    const rawText = (data.content || []).map(b => b.text || '').join('');

    // Try to extract JSON robustly
    let parsed = null;
    try { parsed = JSON.parse(rawText); } catch(e) {}
    if (!parsed) {
      const cleaned = rawText.replace(/```json/gi, '').replace(/```/g, '').trim();
      try { parsed = JSON.parse(cleaned); } catch(e) {}
    }
    if (!parsed) {
      const start = rawText.indexOf('{');
      const end = rawText.lastIndexOf('}');
      if (start !== -1 && end !== -1) {
        try { parsed = JSON.parse(rawText.slice(start, end + 1)); } catch(e) {}
      }
    }

    if (!parsed) {
      return res.status(500).json({ error: 'Failed to parse AI response', raw: rawText.slice(0, 300) });
    }

    return res.status(200).json(parsed);

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
